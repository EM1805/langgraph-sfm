[![PyPI](https://img.shields.io/pypi/v/langgraph-sfm.svg)](https://pypi.org/project/langgraph-sfm/)
[![Python](https://img.shields.io/pypi/pyversions/langgraph-sfm.svg)](https://pypi.org/project/langgraph-sfm/)
[![License](https://img.shields.io/pypi/l/langgraph-sfm.svg)](https://pypi.org/project/langgraph-sfm/)

# langgraph-sfm

**Causal intent monitoring for LangGraph agents using a bundled Structural Final Models core.**

`langgraph-sfm` adds an SFM intent-analysis node and run monitor to LangGraph-style agent workflows. This package now bundles the full relocated SFM core under a single `sfm/` package, so the default node uses the real core backend instead of a lightweight fallback.

## Install

```bash
pip install langgraph-sfm
# optional, only when running inside LangGraph itself
pip install "langgraph-sfm[langgraph]"
```

## Quickstart

```python
from sfm_langgraph import SFMIntentAnalyzerNode, SFMAgentMonitor

analyzer = SFMIntentAnalyzerNode()
monitor = SFMAgentMonitor()

state = {
    "run_id": "agent-run-1",
    "last_action": "call_search_tool",
    "candidate_goals": [{"goal_variable": "answer_user_question"}],
    "graph": {
        "nodes": ["agent_action", "answer_user_question"],
        "edges": [["agent_action", "answer_user_question"]],
    },
    "stated_goal": "answer_user_question",
}

state.update(analyzer(state))
state.update(monitor(state))

print(state["sfm_analysis"])
print(state["sfm_monitor"])
```

## Hugging Face Space demo

A ready-to-copy Gradio demo is included in:

```text
huggingface_space/
  app.py
  requirements.txt
  README.md
```

It installs `langgraph-sfm` from PyPI and exposes an interactive agent-intent monitor with:

- declared goal
- proposed agent action
- candidate goals
- observed effects
- SFM analysis
- allow / review / block gate
- monitor trace

To deploy it, create a new Hugging Face Space with SDK `Gradio`, then copy the files from `huggingface_space/` into the Space repository.

## What is inside

```text
sfm_langgraph/   # LangGraph-compatible node, monitor and CLI
sfm/             # bundled full SFM core and its required support modules
tests/           # public smoke/contract tests
examples/        # quickstart examples
huggingface_space/ # Gradio demo files for Hugging Face Spaces
```

The bundled core keeps the public repository clean: instead of publishing many top-level internal packages (`amantia`, `runtime`, `scm_parts`, etc.), they live inside `sfm/`. A small compatibility bootstrap preserves the core's internal imports.

## LangGraph usage

```python
from typing import Any, TypedDict
from langgraph.graph import END, START, StateGraph
from sfm_langgraph import SFMIntentAnalyzerNode, SFMAgentMonitor

class AgentState(TypedDict, total=False):
    run_id: str
    last_action: str
    candidate_goals: list[dict[str, Any]]
    graph: dict[str, Any]
    stated_goal: str
    sfm_analysis: dict[str, Any]
    sfm_monitor: dict[str, Any]
    requires_human_review: bool
    sfm_gate_status: str

builder = StateGraph(AgentState)
builder.add_node("sfm_intent", SFMIntentAnalyzerNode())
builder.add_node("sfm_monitor", SFMAgentMonitor())
builder.add_edge(START, "sfm_intent")
builder.add_edge("sfm_intent", "sfm_monitor")
builder.add_edge("sfm_monitor", END)
graph = builder.compile()
```

## Epistemic boundary

This project is a research/observability layer. It does not prove an agent's “true goal”. It reports plausible intent hypotheses, side effects, deception-risk signals and the level at which a claim is authorized or withheld.

Recommended wording:

> Detect plausible agent intentions, side effects, and deception risk with explicit epistemic claim levels.

## Development

```bash
python -m pip install -e ".[test]"
python -m pytest
python -m sfm_langgraph.cli
python -m build
```

## License

MIT.

## Experimental: LangGraph-SFM Trading Guard

This package now includes an experimental **Trading Guard** scaffold for paper/testnet trading-agent experiments.

It is **not financial advice** and it is **not a profit engine**. Its purpose is to show how SFM can act as a governance layer around an agent that proposes market actions.

Architecture:

```text
market snapshot
  -> strategy proposal
  -> SFM intent / side-effect analysis
  -> deterministic risk policy gate
  -> allow / review / block
  -> paper execution by default
  -> audit log + SFM monitor
```

Quick paper demo:

```bash
pip install -e ".[langgraph]"
python examples/trading_guard_demo.py
```

CLI:

```bash
langgraph-sfm-trading-guard --mode paper --symbol BTC/USDT --max-notional 5 --json
```

Core safety defaults:

- paper execution by default
- spot-only assumptions
- no margin / no futures
- max notional per trade
- max daily notional
- max trades per day
- stop-loss required for buys
- live mode disabled unless explicitly acknowledged
- JSON audit trail

Optional Binance integration is exposed through `sfm_langgraph.trading.CCXTBinanceSpotBroker`, but the reusable LangGraph workflow executes paper orders only. For any real order, first call `evaluate_trade_policy(...)` and execute only if the gate returns `allow`.

## Experimental trading guard with optional LLM/news advisor

`langgraph-sfm` now includes an experimental paper/testnet trading guard scaffold. It is **not financial advice** and it is **not a profit engine**. Its purpose is to show how a tool-using agent can be constrained by deterministic risk policy plus SFM monitoring.

The trading workflow can read:

- recent prices / technical signals
- manual or fetched news headlines
- optional LLM market-risk summaries
- hard risk limits such as max notional, allowed symbols, stop-loss requirements, and daily trade caps

The LLM is advisory only. It can classify news and signals into a structured market view, but it cannot execute trades. Orders still pass through:

```text
market snapshot → news/signal advisor → SMA strategy → SFM query → hard risk gate → paper execution or skip
```

Install for local paper tests:

```bash
pip install -e ".[langgraph]"
python examples/trading_guard_demo.py
python examples/trading_guard_llm_news_demo.py
```

Use the CLI with heuristic news/signal analysis:

```bash
langgraph-sfm-trading-guard \
  --mode paper \
  --symbol BTC/USDT \
  --news "Exchange hack and regulatory investigation reported" \
  --signal "rsi=82:bearish:0.7" \
  --json
```

Use the optional LLM advisor:

```bash
pip install -e ".[langgraph,llm]"
export OPENAI_API_KEY="..."
langgraph-sfm-trading-guard \
  --mode paper \
  --symbol BTC/USDT \
  --use-llm-advisor \
  --llm-model gpt-4o-mini \
  --news "ETF inflows rise while volatility remains elevated" \
  --json
```

Safety behavior:

- `allow` means the hard policy passed and the packaged graph executes only a paper order.
- `review` means a human should inspect the proposal before any real execution.
- `block` means the agent recommends `no_trade` or safer modifications such as reducing size, adding a stop-loss, waiting for cooldown, or switching back to paper/testnet.

For Binance or other brokers, keep API keys without withdrawal permissions and connect a live executor only after `evaluate_trade_policy(...)` returns `allow` under your explicit policy.

## Autonomous Trading Guard Runner

The package now includes an experimental autonomous runner for paper/testnet-first trading-agent experiments.

It adds:

```text
sfm_langgraph/trading/runner.py              # scheduled autonomous loop
sfm_langgraph/trading/market_data.py         # static + ccxt market/account providers
sfm_langgraph/trading/execution.py           # gated execution engine
sfm_langgraph/trading/order_normalizer.py    # exchange filter / quantity normalization
sfm_langgraph/trading/position_manager.py    # exposure tracking helpers
sfm_langgraph/trading/stop_manager.py        # stop-loss / take-profit planning
sfm_langgraph/trading/kill_switch.py         # file/env emergency stop
sfm_langgraph/trading/alerts.py              # console, memory, Telegram alerts
sfm_langgraph/trading/storage.py             # JSONL audit log
```

Run a paper-only autonomous loop:

```bash
langgraph-sfm-trading-runner \
  --mode paper \
  --symbol BTC/USDT \
  --cycles 2 \
  --interval-sec 0 \
  --max-notional 5 \
  --news "ETF inflows rise while volatility remains elevated" \
  --signal "trend=sma_up:bullish:0.65" \
  --json
```

Emergency stop:

```bash
touch KILL_SWITCH
# or
export SFM_TRADING_KILL_SWITCH=true
```

The runner is deliberately conservative: the LLM/news advisor can only provide market context, SFM and deterministic risk policy must return `allow`, and real broker execution remains disabled unless explicitly enabled by the caller.


## LIVE_LOCKED mode

The autonomous runner now includes a separate live-locked path for tiny real
Binance Spot experiments. It refuses live real execution unless both the CLI
acknowledgement and the environment acknowledgement are present, and it enforces
small hard caps: max 10 quote notional per trade, max 20 daily quote notional,
max 20 open exposure, max 2 trades/day, max 5 cycles, no endless live loop, and
a minimum 300 second interval when cycles > 1.

See `examples/trading_guard/BINANCE_LIVE_LOCKED_SETUP.md` and
`examples/trading_guard/.env.live.example`.


## LIVE_OPERATIVE mode

`LIVE_OPERATIVE` is a less restrictive live profile for small real-money experiments.
It still requires explicit live acknowledgement plus a second operative acknowledgement,
and it remains spot-only, finite-cycle, withdrawal-free, and capped.

Typical command:

```bash
export BINANCE_LIVE_API_KEY="..."
export BINANCE_LIVE_API_SECRET="..."
export SFM_TRADING_LIVE_ACK="I_UNDERSTAND_LIVE_TRADING_CAN_LOSE_MONEY"
export SFM_TRADING_LIVE_PROFILE="operative"
export SFM_TRADING_OPERATIVE_ACK="I_ACCEPT_HIGHER_AUTONOMY_RISK"

python -m sfm_langgraph.trading.autonomous_cli   --mode live   --use-binance-data   --enable-real-execution   --allow-live   --live-ack   --live-profile operative   --operative-ack   --symbol BTC/USDT   --cycles 24   --interval-sec 300   --max-notional 20   --max-daily-notional 80   --max-open-position 80   --max-trades-per-day 8   --json
```

See `examples/trading_guard/BINANCE_LIVE_OPERATIVE_SETUP.md`.
