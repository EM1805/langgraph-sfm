from pathlib import Path

from sfm_langgraph.trading import (
    AutonomousTradingConfig,
    AutonomousTradingRunner,
    KillSwitch,
    MemoryAlertSink,
    NullTradeStore,
    OrderConstraints,
    StaticMarketDataProvider,
    TradeProposal,
    normalize_market_order,
)


def test_kill_switch_blocks_autonomous_runner(tmp_path: Path):
    kill = tmp_path / "KILL_SWITCH"
    kill.write_text("true")
    alerts = MemoryAlertSink()
    runner = AutonomousTradingRunner(
        AutonomousTradingConfig(mode="paper", symbol="BTC/USDT"),
        store=NullTradeStore(),
        kill_switch=KillSwitch(path=kill),
        alert_sink=alerts,
    )
    result = runner.run_once()
    assert result["gate_decision"] == "block"
    assert "kill_switch_active" in result["violations"]
    assert alerts.alerts


def test_autonomous_runner_writes_cycle_and_dry_run_execution(tmp_path: Path):
    store_path = tmp_path / "audit.jsonl"
    config = AutonomousTradingConfig(
        mode="testnet",
        symbol="BTC/USDT",
        store_path=str(store_path),
        risk_policy={"mode": "testnet", "allowed_symbols": ["BTC/USDT"], "max_notional_quote": 5.0},
        enable_real_execution=False,
    )
    provider = StaticMarketDataProvider(prices=[100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111])
    result = AutonomousTradingRunner(config, market_data=provider, alert_sink=MemoryAlertSink()).run_once()
    assert result["autonomous"]["real_execution_enabled"] is False
    assert result["broker_execution_report"]["status"] in {"dry_run_only", "not_submitted"}
    assert store_path.exists()
    assert "trading_guard_cycle" in store_path.read_text()


def test_order_normalizer_enforces_min_notional_and_step():
    too_small = normalize_market_order(
        TradeProposal(symbol="BTC/USDT", side="buy", notional_quote=3.0),
        last_price=100.0,
        constraints=OrderConstraints(min_notional=5.0, step_size=0.001),
    )
    assert not too_small.valid
    assert too_small.reason == "below_exchange_min_notional"

    ok = normalize_market_order(
        TradeProposal(symbol="BTC/USDT", side="buy", notional_quote=10.0),
        last_price=300.0,
        constraints=OrderConstraints(min_notional=5.0, step_size=0.01),
    )
    assert ok.valid
    assert ok.proposal.quantity_base == 0.03
