from pathlib import Path

import pytest

from sfm_langgraph.trading import (
    AutonomousTradingConfig,
    AutonomousTradingRunner,
    LiveLockedConfigError,
    MemoryAlertSink,
    NullTradeStore,
    StaticMarketDataProvider,
    LIVE_ACK_VALUE,
    validate_live_locked_config,
)


def _live_policy(**overrides):
    data = {
        "mode": "live",
        "allowed_symbols": ["BTC/USDT"],
        "max_notional_quote": 10.0,
        "max_daily_notional_quote": 20.0,
        "max_open_position_quote": 20.0,
        "max_trades_per_day": 2,
        "allow_live_trading": True,
        "allow_margin": False,
        "allow_futures": False,
    }
    data.update(overrides)
    return data


def test_live_locked_requires_ack(monkeypatch):
    monkeypatch.delenv("SFM_TRADING_LIVE_ACK", raising=False)
    with pytest.raises(LiveLockedConfigError):
        validate_live_locked_config(
            mode="live",
            enable_real_execution=True,
            live_ack_confirmed=True,
            risk_policy=_live_policy(),
            max_cycles=1,
            interval_seconds=900,
            symbol="BTC/USDT",
        )


def test_live_locked_rejects_endless_or_oversized(monkeypatch):
    monkeypatch.setenv("SFM_TRADING_LIVE_ACK", LIVE_ACK_VALUE)
    with pytest.raises(LiveLockedConfigError):
        validate_live_locked_config(
            mode="live",
            enable_real_execution=True,
            live_ack_confirmed=True,
            risk_policy=_live_policy(max_notional_quote=11.0),
            max_cycles=1,
            interval_seconds=900,
            symbol="BTC/USDT",
        )
    with pytest.raises(LiveLockedConfigError):
        validate_live_locked_config(
            mode="live",
            enable_real_execution=True,
            live_ack_confirmed=True,
            risk_policy=_live_policy(),
            max_cycles=0,
            interval_seconds=900,
            symbol="BTC/USDT",
        )


def test_live_locked_runner_can_start_safely_without_submitting_when_gate_reviews(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("SFM_TRADING_LIVE_ACK", LIVE_ACK_VALUE)
    cfg = AutonomousTradingConfig(
        mode="live",
        symbol="BTC/USDT",
        interval_seconds=900,
        max_cycles=1,
        risk_policy=_live_policy(),
        enable_real_execution=True,
        live_ack_confirmed=True,
        store_path=str(tmp_path / "audit.jsonl"),
    )
    provider = StaticMarketDataProvider(prices=[100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111])
    result = AutonomousTradingRunner(
        cfg,
        market_data=provider,
        store=NullTradeStore(),
        alert_sink=MemoryAlertSink(),
        broker=None,
    ).run_once()
    assert result["mode"] == "live"
    assert result["broker_execution_report"]["status"] in {"not_submitted", "dry_run_only", "blocked_client_side"}


def test_live_operative_profile_requires_second_ack(monkeypatch):
    from sfm_langgraph.trading import OPERATIVE_ACK_VALUE

    monkeypatch.setenv("SFM_TRADING_LIVE_ACK", LIVE_ACK_VALUE)
    monkeypatch.delenv("SFM_TRADING_OPERATIVE_ACK", raising=False)
    with pytest.raises(LiveLockedConfigError):
        validate_live_locked_config(
            mode="live",
            enable_real_execution=True,
            live_ack_confirmed=True,
            operative_ack_confirmed=False,
            live_profile="operative",
            risk_policy=_live_policy(
                max_notional_quote=25.0,
                max_daily_notional_quote=100.0,
                max_open_position_quote=100.0,
                max_trades_per_day=12,
            ),
            max_cycles=24,
            interval_seconds=60,
            symbol="SOL/USDT",
        )

    monkeypatch.setenv("SFM_TRADING_OPERATIVE_ACK", OPERATIVE_ACK_VALUE)
    validate_live_locked_config(
        mode="live",
        enable_real_execution=True,
        live_ack_confirmed=True,
        operative_ack_confirmed=True,
        live_profile="operative",
        risk_policy=_live_policy(
            max_notional_quote=25.0,
            max_daily_notional_quote=100.0,
            max_open_position_quote=100.0,
            max_trades_per_day=12,
        ),
        max_cycles=24,
        interval_seconds=60,
        symbol="SOL/USDT",
    )


def test_live_operative_profile_still_rejects_unbounded(monkeypatch):
    monkeypatch.setenv("SFM_TRADING_LIVE_ACK", LIVE_ACK_VALUE)
    monkeypatch.setenv("SFM_TRADING_OPERATIVE_ACK", "I_ACCEPT_HIGHER_AUTONOMY_RISK")
    with pytest.raises(LiveLockedConfigError):
        validate_live_locked_config(
            mode="live",
            enable_real_execution=True,
            live_ack_confirmed=True,
            operative_ack_confirmed=True,
            live_profile="operative",
            risk_policy=_live_policy(
                max_notional_quote=26.0,
                max_daily_notional_quote=100.0,
                max_open_position_quote=100.0,
                max_trades_per_day=12,
            ),
            max_cycles=24,
            interval_seconds=60,
            symbol="BTC/USDT",
        )
