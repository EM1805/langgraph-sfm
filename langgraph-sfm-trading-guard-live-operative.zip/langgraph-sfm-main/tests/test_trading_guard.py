from sfm_langgraph.trading import (
    TradeProposal,
    TradingRiskPolicy,
    evaluate_trade_policy,
    run_trading_guard_cycle,
)


def test_trading_policy_blocks_oversized_trade():
    result = evaluate_trade_policy(
        TradeProposal(symbol="BTC/USDT", side="buy", notional_quote=50.0, stop_loss_pct=1.0, confidence=0.8),
        TradingRiskPolicy(max_notional_quote=5.0),
    )
    assert result.decision == "block"
    assert "oversized_trade" in result.violations


def test_trading_guard_cycle_returns_gate_and_execution_report():
    result = run_trading_guard_cycle({"mode": "paper", "symbol": "BTC/USDT"})
    assert "proposal" in result
    assert "gate" in result
    assert "execution_report" in result
    assert result["execution_report"]["mode"] in {"paper", "testnet", "live"}

from sfm_langgraph.trading import HeuristicNewsSignalAdvisor, MarketSnapshot


def test_heuristic_news_advisor_flags_high_risk_news():
    advisor = HeuristicNewsSignalAdvisor()
    view = advisor.analyze(
        market=MarketSnapshot(symbol="BTC/USDT", last_price=100.0),
        news_items=[{"title": "Major exchange hack and regulatory investigation"}],
        signals=[],
    )
    assert view.risk_level == "high"
    assert view.trade_bias == "no_trade"


def test_trading_guard_blocks_when_news_advisor_is_high_risk():
    result = run_trading_guard_cycle(
        {
            "mode": "paper",
            "symbol": "BTC/USDT",
            "news_items": [{"title": "Exchange hack and trading outage reported"}],
            "external_signals": [{"name": "rsi", "value": 82, "direction": "bearish", "confidence": 0.7}],
            "use_llm_advisor": False,
            "risk_policy": {"mode": "paper", "allowed_symbols": ["BTC/USDT"], "max_notional_quote": 5.0},
        }
    )
    assert result["llm_market_view"]["risk_level"] == "high"
    assert result["gate_decision"] == "block"
    assert "llm_news_high_risk" in result["violations"]
    assert result["execution_report"]["executed"] is False
