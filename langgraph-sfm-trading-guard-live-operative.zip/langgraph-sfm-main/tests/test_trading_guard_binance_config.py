import os

import pytest

from sfm_langgraph.trading.binance_env import binance_env_credentials, require_binance_env_credentials


def test_testnet_credentials_prefer_testnet_env(monkeypatch):
    monkeypatch.setenv("BINANCE_TESTNET_API_KEY", "testnet-key")
    monkeypatch.setenv("BINANCE_TESTNET_API_SECRET", "testnet-secret")
    monkeypatch.setenv("BINANCE_API_KEY", "generic-key")
    monkeypatch.setenv("BINANCE_API_SECRET", "generic-secret")
    monkeypatch.setenv("BINANCE_LIVE_API_KEY", "live-key")
    monkeypatch.setenv("BINANCE_LIVE_API_SECRET", "live-secret")
    assert binance_env_credentials(mode="testnet") == ("testnet-key", "testnet-secret")
    assert binance_env_credentials(mode="live") == ("live-key", "live-secret")


def test_require_binance_credentials_raises_clear_error(monkeypatch):
    for name in ["BINANCE_TESTNET_API_KEY", "BINANCE_TESTNET_API_SECRET", "BINANCE_API_KEY", "BINANCE_API_SECRET"]:
        monkeypatch.delenv(name, raising=False)
    with pytest.raises(RuntimeError, match="Missing Binance credentials"):
        require_binance_env_credentials(mode="testnet")
