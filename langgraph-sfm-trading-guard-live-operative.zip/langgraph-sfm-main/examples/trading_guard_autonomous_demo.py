"""Autonomous paper-runner demo for LangGraph-SFM Trading Guard.

This demo runs two guarded paper cycles and writes a JSONL audit log.  It does
not submit real orders.
"""

from pathlib import Path

from sfm_langgraph.trading import AutonomousTradingConfig, AutonomousTradingRunner, MemoryAlertSink, StaticMarketDataProvider


if __name__ == "__main__":
    log_path = Path("examples/trading_guard/autonomous_demo_audit.jsonl")
    if log_path.exists():
        log_path.unlink()

    config = AutonomousTradingConfig(
        mode="paper",
        symbol="BTC/USDT",
        interval_seconds=0.0,
        max_cycles=2,
        store_path=str(log_path),
        risk_policy={
            "mode": "paper",
            "allowed_symbols": ["BTC/USDT"],
            "max_notional_quote": 5.0,
            "max_daily_notional_quote": 20.0,
            "max_trades_per_day": 3,
        },
        news_items=[{"title": "ETF inflows rise while volatility remains elevated", "source": "demo"}],
        external_signals=[{"name": "trend", "value": "sma_up", "direction": "bullish", "confidence": 0.65}],
    )
    market_data = StaticMarketDataProvider(prices=[100, 100.5, 101, 101.4, 102, 103, 104, 105, 106, 107, 108, 109])
    alerts = MemoryAlertSink()
    runner = AutonomousTradingRunner(config, market_data=market_data, alert_sink=alerts)

    for result in runner.run_forever():
        print("cycle", result["autonomous"]["cycle_index"], "gate", result.get("gate_decision"), result.get("gate_reason"))
        print("broker", result.get("broker_execution_report"))

    print("audit log:", log_path)
    print("alerts:", alerts.alerts)
