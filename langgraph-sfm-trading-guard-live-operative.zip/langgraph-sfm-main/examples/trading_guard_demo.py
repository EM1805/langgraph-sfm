"""Paper-only demo for the LangGraph-SFM trading guard.

Run:
    python examples/trading_guard_demo.py

This demo never sends real orders.  It runs a small SMA strategy through SFM
analysis and a hard risk policy gate, then executes only a paper order if the
gate allows.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sfm_langgraph.trading import run_trading_guard_cycle


if __name__ == "__main__":
    result = run_trading_guard_cycle(
        {
            "mode": "paper",
            "symbol": "BTC/USDT",
            "prices": [101, 100.7, 100.9, 101.3, 101.8, 102.1, 102.4, 102.9, 103.3, 103.6, 104.2, 104.7],
            "news_items": [
                {
                    "title": "ETF inflows remain positive while volatility is moderate",
                    "summary": "Manual demo headline used as optional advisor context.",
                    "source": "manual-demo",
                }
            ],
            "external_signals": [
                {"name": "trend_filter", "value": "positive", "direction": "bullish", "confidence": 0.65}
            ],
            "use_llm_advisor": False,
            "risk_policy": {
                "mode": "paper",
                "allowed_symbols": ["BTC/USDT", "ETH/USDT"],
                "max_notional_quote": 5.0,
                "max_daily_notional_quote": 20.0,
                "max_trades_per_day": 3,
                "allow_live_trading": False,
            },
            "prior_trades_today": [],
            "open_position_quote": 0.0,
        }
    )
    print(json.dumps({
        "proposal": result.get("proposal"),
        "market_view": result.get("llm_market_view"),
        "gate": result.get("gate"),
        "execution_report": result.get("execution_report"),
        "sfm_analysis": result.get("sfm_analysis"),
    }, indent=2, sort_keys=True))
