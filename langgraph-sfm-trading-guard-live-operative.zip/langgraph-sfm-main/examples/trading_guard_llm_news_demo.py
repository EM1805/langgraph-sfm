"""Paper demo: trading guard with news/signals advisor.

This demo does not call an LLM unless you set ``use_llm_advisor=True`` and
provide ``OPENAI_API_KEY``.  Without a key it uses the deterministic heuristic
fallback.  No real orders are submitted.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sfm_langgraph.trading import run_trading_guard_cycle


if __name__ == "__main__":
    result = run_trading_guard_cycle(
        {
            "mode": "paper",
            "symbol": "BTC/USDT",
            "prices": [101, 100.7, 100.9, 101.3, 101.8, 102.1, 102.4, 102.9, 103.3, 103.6, 104.2, 104.7],
            "news_items": [
                {
                    "title": "Major exchange outage and regulatory investigation reported",
                    "summary": "Unverified reports mention an outage, investigation, and possible customer fund risk.",
                    "source": "manual-demo",
                }
            ],
            "external_signals": [
                {"name": "rsi", "value": 78, "direction": "bearish", "confidence": 0.7, "source": "manual-demo"}
            ],
            "use_llm_advisor": False,
            "risk_policy": {
                "mode": "paper",
                "allowed_symbols": ["BTC/USDT", "ETH/USDT"],
                "max_notional_quote": 5.0,
                "max_daily_notional_quote": 20.0,
                "max_trades_per_day": 3,
                "allow_live_trading": False,
            },
            "prior_trades_today": [],
            "open_position_quote": 0.0,
        }
    )
    print(
        json.dumps(
            {
                "market_view": result.get("llm_market_view"),
                "proposal": result.get("proposal"),
                "gate": result.get("gate"),
                "execution_report": result.get("execution_report"),
            },
            indent=2,
            sort_keys=True,
        )
    )
