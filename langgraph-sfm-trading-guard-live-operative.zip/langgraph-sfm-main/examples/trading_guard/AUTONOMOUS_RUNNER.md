# Autonomous Trading Runner

This module turns the trading guard into an autonomous **paper/testnet-first** runner.
It is still a risk-control scaffold, not a profit system.

## Safety defaults

- Paper mode by default.
- Real execution is disabled unless `enable_real_execution=True`.
- Live trading is blocked unless the risk policy explicitly allows it and the live acknowledgement is configured.
- A file/env kill switch blocks new orders.
- Every cycle writes a JSONL audit record.
- SFM and hard risk policy must return `allow` before a broker receives an order.

## Run a local paper loop

```bash
python examples/trading_guard_autonomous_demo.py
```

or:

```bash
langgraph-sfm-trading-runner \
  --mode paper \
  --symbol BTC/USDT \
  --cycles 2 \
  --interval-sec 0 \
  --max-notional 5 \
  --news "ETF inflows rise while volatility remains elevated" \
  --signal "trend=sma_up:bullish:0.65" \
  --json
```

## Emergency stop

Create a kill-switch file next to the process:

```bash
touch KILL_SWITCH
```

or set:

```bash
export SFM_TRADING_KILL_SWITCH=true
```

## Testnet/live progression

1. Paper mode with static prices.
2. Paper mode with live market data.
3. Binance Spot Testnet with real execution enabled.
4. Live mode only with tiny capital, no withdrawals, strict limits, and explicit live acknowledgement.

The runner does not remove trading risk. It only enforces operational controls before orders are submitted.


## LIVE_LOCKED mode

The autonomous runner now includes a separate live-locked path for tiny real
Binance Spot experiments. It refuses live real execution unless both the CLI
acknowledgement and the environment acknowledgement are present, and it enforces
small hard caps: max 10 quote notional per trade, max 20 daily quote notional,
max 20 open exposure, max 2 trades/day, max 5 cycles, no endless live loop, and
a minimum 300 second interval when cycles > 1.

See `examples/trading_guard/BINANCE_LIVE_LOCKED_SETUP.md` and
`examples/trading_guard/.env.live.example`.


## LIVE_OPERATIVE mode

`LIVE_OPERATIVE` is a less restrictive live profile for small real-money experiments.
It still requires explicit live acknowledgement plus a second operative acknowledgement,
and it remains spot-only, finite-cycle, withdrawal-free, and capped.

Typical command:

```bash
export BINANCE_LIVE_API_KEY="..."
export BINANCE_LIVE_API_SECRET="..."
export SFM_TRADING_LIVE_ACK="I_UNDERSTAND_LIVE_TRADING_CAN_LOSE_MONEY"
export SFM_TRADING_LIVE_PROFILE="operative"
export SFM_TRADING_OPERATIVE_ACK="I_ACCEPT_HIGHER_AUTONOMY_RISK"

python -m sfm_langgraph.trading.autonomous_cli   --mode live   --use-binance-data   --enable-real-execution   --allow-live   --live-ack   --live-profile operative   --operative-ack   --symbol BTC/USDT   --cycles 24   --interval-sec 300   --max-notional 20   --max-daily-notional 80   --max-open-position 80   --max-trades-per-day 8   --json
```

See `examples/trading_guard/BINANCE_LIVE_OPERATIVE_SETUP.md`.
