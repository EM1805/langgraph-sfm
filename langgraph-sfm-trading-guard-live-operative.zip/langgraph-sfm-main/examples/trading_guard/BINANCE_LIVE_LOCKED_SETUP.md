# Binance LIVE_LOCKED setup for LangGraph-SFM Trading Guard

This is for **real Binance Spot live trading** with intentionally tiny limits.
It is not a profit system and not financial advice. It exists to test an
agentic trading workflow with hard safety gates.

## Hard live-locked limits

The runner refuses live real execution unless all of these are true:

- `--enable-real-execution`
- `--allow-live`
- `--live-ack`
- `SFM_TRADING_LIVE_ACK=I_UNDERSTAND_LIVE_TRADING_CAN_LOSE_MONEY`
- `BINANCE_LIVE_API_KEY` and `BINANCE_LIVE_API_SECRET` are set
- symbol is `BTC/USDT` or `ETH/USDT`
- `max_notional <= 10`
- `max_daily_notional <= 20`
- `max_open_position <= 20`
- `max_trades_per_day <= 2`
- `cycles <= 5`
- no endless live loop
- if cycles > 1, `interval_sec >= 300`
- margin/futures are disabled by policy

## API key safety

Create a dedicated live API key and keep it narrow:

- Reading: on
- Spot trading: on
- Withdrawals: off
- Futures: off
- Margin: off
- IP restriction: on if available

Never paste keys into chat. Never commit `.env`.

## Install

```bash
pip install -e ".[trading,llm]"
```

## Create `.env`

```bash
cp examples/trading_guard/.env.live.example .env
```

Edit `.env`:

```bash
BINANCE_LIVE_API_KEY=...
BINANCE_LIVE_API_SECRET=...
SFM_TRADING_LIVE_ACK=I_UNDERSTAND_LIVE_TRADING_CAN_LOSE_MONEY
```

## First live-locked run

Use one or a few slow cycles. This command still submits orders only if the
strategy proposes a trade and SFM + hard policy return `allow`.

```bash
python -m sfm_langgraph.trading.autonomous_cli \
  --mode live \
  --use-binance-data \
  --enable-real-execution \
  --allow-live \
  --live-ack \
  --symbol BTC/USDT \
  --cycles 3 \
  --interval-sec 900 \
  --max-notional 10 \
  --max-daily-notional 20 \
  --max-open-position 20 \
  --max-trades-per-day 2 \
  --json
```

## Emergency stop

Any of these blocks new cycles:

```bash
touch KILL_SWITCH
# or
export SFM_TRADING_KILL_SWITCH=true
```

Remove the file or unset the variable only when you intentionally resume.
