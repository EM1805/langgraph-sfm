# LangGraph-SFM Trading Guard

Experimental scaffold for a guarded trading agent.

It combines:

- LangGraph workflow orchestration
- a deterministic SMA strategy node
- SFM intent/side-effect analysis
- hard risk policy checks
- paper-only execution by default
- optional Binance Spot adapter through `ccxt`

This is **not financial advice** and not a profit engine. It is a safety/governance
example for agentic tool use.

## Quick demo

```bash
pip install -e ".[langgraph]"
python examples/trading_guard_demo.py
```

or:

```bash
langgraph-sfm-trading-guard --mode paper --symbol BTC/USDT --max-notional 5 --json
```

## Live trading guardrails

The reusable LangGraph workflow executes paper orders only. If you want to wire
Binance yourself, first call `evaluate_trade_policy(...)`; only pass the proposal
to `CCXTBinanceSpotBroker` when the gate returns `allow`.

Recommended constraints:

- spot only
- no futures
- no margin
- no withdrawals on API keys
- tiny notional per trade
- daily loss/notional limit
- max trades per day
- stop-loss required
- manual kill switch
- full JSONL audit log

Live mode requires both:

```bash
export SFM_TRADING_LIVE_ACK=I_UNDERSTAND_LIVE_TRADING_CAN_LOSE_MONEY
```

and a policy with:

```yaml
allow_live_trading: true
```

## Optional LLM/news advisor

The trading guard can also read news and external signals before a trade proposal
reaches the SFM/risk gate. The advisor is not an executor and is not allowed to
place trades. It returns a structured market-risk view:

```json
{
  "risk_level": "high",
  "news_sentiment": "mixed",
  "trade_bias": "no_trade",
  "confidence": 0.72,
  "rationale": "High-risk news terms were detected."
}
```

Offline heuristic mode:

```bash
python examples/trading_guard_llm_news_demo.py
```

CLI heuristic mode:

```bash
langgraph-sfm-trading-guard \
  --mode paper \
  --symbol BTC/USDT \
  --news "Exchange hack and regulatory investigation reported" \
  --signal "rsi=82:bearish:0.7" \
  --json
```

Optional LLM mode:

```bash
pip install -e ".[langgraph,llm]"
export OPENAI_API_KEY="..."
langgraph-sfm-trading-guard \
  --mode paper \
  --symbol BTC/USDT \
  --use-llm-advisor \
  --llm-model gpt-4o-mini \
  --news "ETF inflows rise while volatility remains elevated" \
  --json
```

If the LLM returns high risk or `no_trade`, the hard gate blocks execution and
recommends the safest next step, usually `no_trade`, human review, or waiting
for the news risk to clear.


## LIVE_LOCKED mode

The autonomous runner now includes a separate live-locked path for tiny real
Binance Spot experiments. It refuses live real execution unless both the CLI
acknowledgement and the environment acknowledgement are present, and it enforces
small hard caps: max 10 quote notional per trade, max 20 daily quote notional,
max 20 open exposure, max 2 trades/day, max 5 cycles, no endless live loop, and
a minimum 300 second interval when cycles > 1.

See `examples/trading_guard/BINANCE_LIVE_LOCKED_SETUP.md` and
`examples/trading_guard/.env.live.example`.


## LIVE_OPERATIVE mode

`LIVE_OPERATIVE` is a less restrictive live profile for small real-money experiments.
It still requires explicit live acknowledgement plus a second operative acknowledgement,
and it remains spot-only, finite-cycle, withdrawal-free, and capped.

Typical command:

```bash
export BINANCE_LIVE_API_KEY="..."
export BINANCE_LIVE_API_SECRET="..."
export SFM_TRADING_LIVE_ACK="I_UNDERSTAND_LIVE_TRADING_CAN_LOSE_MONEY"
export SFM_TRADING_LIVE_PROFILE="operative"
export SFM_TRADING_OPERATIVE_ACK="I_ACCEPT_HIGHER_AUTONOMY_RISK"

python -m sfm_langgraph.trading.autonomous_cli   --mode live   --use-binance-data   --enable-real-execution   --allow-live   --live-ack   --live-profile operative   --operative-ack   --symbol BTC/USDT   --cycles 24   --interval-sec 300   --max-notional 20   --max-daily-notional 80   --max-open-position 80   --max-trades-per-day 8   --json
```

See `examples/trading_guard/BINANCE_LIVE_OPERATIVE_SETUP.md`.
