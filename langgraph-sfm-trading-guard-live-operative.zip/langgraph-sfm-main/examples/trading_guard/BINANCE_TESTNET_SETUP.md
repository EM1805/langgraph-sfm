# Binance Spot Testnet setup for LangGraph-SFM Trading Guard

This setup is for **Binance Spot Testnet only**. It is designed to test the autonomous runner and gated execution without using real funds.

## 1. Install optional trading dependencies

```bash
pip install -e ".[trading,llm]"
```

The `trading` extra installs `ccxt` and `python-dotenv`.

## 2. Create Spot Testnet credentials

Create credentials on the Binance Spot Test Network and keep them separate from your live Binance API keys. Never commit `.env` and never paste secrets into chat.

## 3. Create `.env`

```bash
cp examples/trading_guard/.env.testnet.example .env
```

Then edit `.env`:

```bash
BINANCE_TESTNET_API_KEY=...
BINANCE_TESTNET_API_SECRET=...
SFM_TRADING_TESTNET_ACK=I_UNDERSTAND_TESTNET_ORDERS
```

## 4. First run: testnet data, no execution

This reads Binance Testnet data/account state but does not submit orders.

```bash
python -m sfm_langgraph.trading.autonomous_cli \
  --mode testnet \
  --use-binance-data \
  --symbol BTC/USDT \
  --cycles 1 \
  --interval-sec 0 \
  --max-notional 5 \
  --json
```

Expected safety outcome: `broker_execution_report.status` is usually `dry_run_only`, `not_submitted`, or `blocked_client_side`.

## 5. Testnet execution

Only after the dry run works, allow sandbox execution:

```bash
python -m sfm_langgraph.trading.autonomous_cli \
  --mode testnet \
  --use-binance-data \
  --enable-real-execution \
  --testnet-ack \
  --symbol BTC/USDT \
  --cycles 1 \
  --interval-sec 0 \
  --max-notional 5 \
  --max-daily-notional 20 \
  --max-trades-per-day 1 \
  --json
```

The runner still submits an order only if all gates pass:

1. strategy proposes buy/sell, not hold;
2. SFM and hard policy return `allow`;
3. Binance constraints normalize the order;
4. `--enable-real-execution` and testnet acknowledgement are present.

## 6. Emergency stop

Any of these blocks new cycles:

```bash
touch KILL_SWITCH
# or
export SFM_TRADING_KILL_SWITCH=true
```

## Notes

- Testnet is not a profit simulation. It validates credentials, order normalization, gating, and execution plumbing.
- Keep live Binance credentials out of this test. Use `BINANCE_TESTNET_API_KEY` and `BINANCE_TESTNET_API_SECRET`.
- For live mode, the package still requires the separate live policy acknowledgement and `allow_live_trading=true`; do not enable live mode until testnet logs are stable.
