# Binance LIVE_OPERATIVE setup for LangGraph-SFM Trading Guard

`LIVE_OPERATIVE` is less restrictive than `LIVE_LOCKED`, but it is still a capped live mode.
It is meant for small live experiments where you want more cycles and a few major symbols,
without enabling futures, margin, withdrawals, or endless loops.

## Hard caps

- max 25 USDT per trade
- max 100 USDT daily notional
- max 100 USDT open position quote
- max 12 trades per day
- max 96 cycles per run
- interval >= 60 seconds when cycles > 1
- allowed symbols: BTC/USDT, ETH/USDT, BNB/USDT, SOL/USDT
- spot only
- no futures
- no margin
- no withdrawals
- no infinite live loop

## Environment

Create a local `.env` or export variables in the terminal. Never commit real keys.

```bash
export BINANCE_LIVE_API_KEY="..."
export BINANCE_LIVE_API_SECRET="..."
export SFM_TRADING_LIVE_ACK="I_UNDERSTAND_LIVE_TRADING_CAN_LOSE_MONEY"
export SFM_TRADING_LIVE_PROFILE="operative"
export SFM_TRADING_OPERATIVE_ACK="I_ACCEPT_HIGHER_AUTONOMY_RISK"
```

## Example run

```bash
python -m sfm_langgraph.trading.autonomous_cli \
  --mode live \
  --use-binance-data \
  --enable-real-execution \
  --allow-live \
  --live-ack \
  --live-profile operative \
  --operative-ack \
  --symbol BTC/USDT \
  --cycles 24 \
  --interval-sec 300 \
  --max-notional 20 \
  --max-daily-notional 80 \
  --max-open-position 80 \
  --max-trades-per-day 8 \
  --json
```

## Emergency stop

Create a kill-switch file in the working directory:

```bash
touch KILL_SWITCH
```

The runner blocks new cycles when the kill switch is active.
