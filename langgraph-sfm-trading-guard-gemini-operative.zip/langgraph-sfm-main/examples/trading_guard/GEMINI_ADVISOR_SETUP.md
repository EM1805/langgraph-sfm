# Gemini advisor setup

The trading guard can use Gemini as an advisory news/signal classifier. Gemini never executes orders directly; it only produces a market-risk view consumed by the SFM/risk gate.

```bash
pip install -e ".[langgraph,llm]"
export GEMINI_API_KEY="..."

python -m sfm_langgraph.trading.autonomous_cli \
  --mode paper \
  --symbol BTC/USDT \
  --cycles 1 \
  --interval-sec 0 \
  --max-notional 10 \
  --use-llm-advisor \
  --llm-provider gemini \
  --llm-model gemini-3.5-flash \
  --news "BTC momentum positive, ETF inflows rising, no major negative regulatory news" \
  --signal "trend=sma_up:bullish:0.75" \
  --json
```

If `GEMINI_API_KEY` or `google-genai` is missing, the advisor falls back to the deterministic heuristic classifier and marks the provider field accordingly.
